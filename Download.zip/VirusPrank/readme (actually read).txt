if the name is something diffrent then "My Computer" its skidded, 
but if it came from this github "https://github.com/startermination"
something went wrong, so rename it to "My Computer" add
swt#0001 for help!